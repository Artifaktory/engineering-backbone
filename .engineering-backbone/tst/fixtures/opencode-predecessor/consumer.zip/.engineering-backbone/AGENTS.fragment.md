# Shared agent instruction fragment

Integrate this fragment into existing agent governance through a reviewed PR.
This file is updated by Copier; it is not automatically discovered as AGENTS.md.



## Essential governance

- Start from an explicit Task Packet: objective, allowed scope, acceptance criteria,
  risk, validation and authorized actions. Read project facts before changing files.
- Project rules may strengthen this baseline; never silently weaken either policy.
- Separate planning, implementation, independent review, quality checks and triage.
  The implementer does not approve their own work. Role profiles do not enforce gates.
- Run the relevant deterministic checks before independent review.
- Review an immutable commit: Full Review → Triage → Fix confirmed finding IDs →
  Delta Review of those fixes and their direct regressions. Keep rejected findings
  with reasons. A broader scope or changed trust boundary requires a new Full Review.
- Treat changes to governance, agents, templates, validators and workflows as HIGH
  risk. Assess downstream effects before recommending adoption.
- Record real commands, results, commit IDs and reviewer identity. Never invent
  checks, approvals, findings or completed runtime integrations.
- Require human approval for merge and release. Never publish a new baseline or
  change repository protections as a side effect of implementation.
- Keep secrets out of files and logs. Preserve existing stronger governance and
  unrelated work; stop and report conflicts rather than overwrite them.

Read the [canonical policy](core.md) and
[project facts](project.json) for the complete contract.

## Shared Codex/Copilot operating contract

- Discover root and applicable path instructions; adapters and skills follow the
  canonical policy. Resolve unexpected repository overrides before acting.
- Independently review non-trivial implementation plans before implementation.
  Identify required versus optional reviewers and obey the recorded task budget.
- Bind each review to base/head revisions and a patch digest. Findings include
  trigger, execution path, impact, evidence, diff causation and a regression check.
  Report coverage and unreviewed areas; exclude style and unrelated existing debt.
- Delta binds the prior reviewed head, repaired head and confirmed IDs. No silent
  reopening of unchanged areas. Default to at most two Full rounds; further rounds
  require a confirmed blocker, relevant new changes or a documented human exception.
- Remote reviews remain advisory without a separately approved formal project
  contract. Provider automation and fixes never bypass local review stops or triage.
- At closeout, map acceptance to actual evidence or pending/blocked/failed status.
  Preserve installed local Publish-Go, signatures and history gates; this baseline
  does not implement or authenticate them. A structural PASS is not semantic review.

## Selected quality context

If `.engineering-backbone/quality-profile.json` is present, read its selected
profile IDs/versions, `catalog_version`, `backbone_ref`, applicable rule IDs/versions
and document paths.
Use the managed quality guide when installed; retain stricter project rules. Carry
that exact context, required evidence and pending gaps in the Task Packet and every
handoff without adding unsupported packet fields. An inactive seed is not adopted;
structural validation is not semantic review, certification or human acceptance.

## Active document navigation

When `.engineering-backbone/navigation.json` is enabled, follow the navigation
guide (`docs/agent-navigation.md` in the source; `.engineering-backbone/navigation-guide.md`
when installed). After a Task Packet exists, resolve its scoped request with the
approved guard, verify received context against the current snapshot, then actually
read every resolved document before scoped work. Transfer the request, complete
context and task acceptance/check/stop/return contract at each handoff; resolve a
new request for a delegated role or narrower scope. Invalid or missing mandatory
context blocks the affected task. An inactive seed, receipt or agent reply does not
prove native instruction loading or authorize additional work.

## Dependency compatibility context

Read `.engineering-backbone/dependency-policy.md` for dependency, runtime or
container work. When `.engineering-backbone/dependencies.json` is enabled, follow
the approved navigation guard to the affected component's compatibility document,
real manifests, resolution/runtime files, Dockerfiles and approved check IDs.
Read and verify those inputs at handoff; changed files invalidate prior context.
Keep versions in their authoritative files and run actual dependency/build/test
and applicable container checks. Resolution, security scans and hashes alone are
not behavioral compatibility. Stay within project constraints and the authorized
task; routine choices need no extra approval solely for being dependency changes.
An inactive seed does not establish adoption. Preserve stricter local gates.

