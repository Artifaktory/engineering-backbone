# Activate a pinned governance workflow after review

The template does not enable a workflow by default. First seed the copied bundle
in a reviewed PR with this caller inactive. After that consumer baseline is merged,
add this caller in a separate activation PR using the human-approved backbone
workflow commit SHA instead of `PIN_APPROVED_COMMIT`. Confirm private-repository workflow access
with the owner first. A valid-looking SHA alone is not proof of approval or access.

```yaml
name: Engineering Backbone
on:
  pull_request:
  workflow_dispatch:
  push:
    branches: ["main"]
permissions:
  contents: read
jobs:
  governance:
    uses: Artifaktory/engineering-backbone/.github/workflows/governance-checks.yml@PIN_APPROVED_COMMIT
    permissions:
      contents: read
```

Supplying `backbone_workflow_ref` during installation emits an active caller;
do that only when a complete reviewed bundle already exists on the consumer base.
Otherwise the first adoption PR fails closed. Existing
`.github/workflows/engineering-backbone.yml` is preserved. There are no secrets or
private source checkout tokens: the workflow runs the consumer base's validator,
schemas and dependency lock against the candidate with `--trusted-base`.
Before execution, immutable workflow fingerprints attest all eight toolchain files
in both base and candidate. Candidate tools must remain at the approved base or
match the new workflow's current tuple; mixed versions or no-op replacements fail.
It never executes the candidate validator or installs its dependencies.
Keep language-specific checks in the consuming project's existing CI.

`backbone_workflow_ref` is installation-only. Changing activation or an existing
pin needs a separate reviewed workflow migration. A manually owned caller can be
added or repinned without editing installation-only saved answers; an ordinary
Copier baseline update rejects changing that selection.

PR checks compare explicit base/head revisions. Push checks compare the previous
push commit to the current commit; a zero previous SHA cannot supply trusted
consumer tooling. Manual dispatch validates the selected candidate using the
repository default branch's trusted bundle; an unmerged selected commit cannot
supply its own trusted tooling. Whitespace is checked against the selected
commit's parent (or the empty tree for a root commit), while policy is compared
against the default branch. Source mode is reserved for the backbone
repository. Keep the caller and its immutable pin under protected human review.

If Copier updates the validator, schemas or dependency manifests, update this
caller to the matching newly reviewed workflow commit in the same PR. That
workflow must retain the previous base's fingerprint. Do not edit a local hash or
supply an allowlist: authority is part of the immutable central workflow. Project
facts and stronger local policy remain separately validated, and base-enabled
providers cannot be disabled through metadata. Scoped managed Git attributes keep
the eight tooling files at LF on Windows and Linux.
