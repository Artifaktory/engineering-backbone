# Engineering Backbone adoption

This directory contains the selected foundation and project facts. Language and
frontend/backend flags are descriptive metadata; they do not invent application
commands, workflows or required infrastructure.

- Review [project facts](project.json) and the [canonical policy](core.md).
- Read [the dependency policy](dependency-policy.md) for dependency, runtime and
  container changes; actual component versions remain project facts.
- Integrate [agent guidance](AGENTS.fragment.md) and
  [Copilot guidance](Copilot.fragment.md) into existing stronger instructions.
- [Copilot operating guide and diagram](copilot-guide.md) record the permanent
  plan/check/Full/triage/fix/Delta/human-decision loop. The guide is reference material
  when Copilot is not selected and is not automatically loaded by the product.
- Existing `AGENTS.md`, Copilot instructions, native role profiles and project
  facts, Copilot skills and path rules are preserved, including during updates.
  New files are created only when
  absent. Later baseline changes therefore require a reviewed manual refresh of
  those entrypoints/profiles; a successful Copier update alone is not full adoption.
- Commit `copier-answers.yml` and use an explicit reviewed Git commit or release
  reference for updates. Review core and fragment changes, refresh protected files
  as needed, and run project checks before merging the update PR.
- Never use automatic merge or publish the baseline from the generated project.

The template has no tasks, migrations or shell hooks. The validation command is
recorded as data; Copier never runs it. Native role definitions need a supported
local Codex/Copilot client and runtime verification. GitHub code-review settings
must be configured separately.

When selected, Copilot supplies ten profiles and eight procedural skills, with
the original planner/implementer/reviewer kept compatible. Core governance/test/docs
path instructions accompany Copilot; Python/frontend examples are separately
selected and do not impose an application framework or commands. Tool budgets do
not enforce path isolation; an execute-capable quality checker can write via shell
and must follow approved packet commands and scope. Independent reviews require
separate sessions and frozen revisions, even where handoff buttons are available.

Install the generated validator's pinned, hashed dependencies in an isolated
Python 3.12 environment:
`python -m pip install --require-hashes -r .engineering-backbone/requirements.lock`.
Then run `python .engineering-backbone/validate.py --root .`. The companion
`requirements.txt` records direct dependencies; lock compilation is central
maintenance, not a template execution hook.

From the consumer repository, invoke updates with the namespaced answers file:
`copier update --answers-file .engineering-backbone/copier-answers.yml --vcs-ref APPROVED_COMMIT`.
Replace the reference with a reviewed commit; this command prepares a diff for review.

The installation choices `use_codex`, `use_copilot`, `backbone_workflow_ref`,
`copilot_python_profile` and `copilot_frontend_profile`
cannot change during a normal template update. The update rejects such changes
before consumer rendering. Adapter changes require their own reviewed migration
of native files, project facts and installation choices. Do not edit or remove
answers merely to bypass this guard.

For a first adoption, leave the workflow choice empty and merge the reviewed seed
bundle with the caller inactive. Add the pinned caller from
[the workflow example](workflow-example.md) in a separate activation PR. A manually
maintained caller can be activated, removed or repinned through a reviewed workflow
migration without changing the saved template-generation choice. The shared gate
executes only the trusted consumer base's validator and dependencies; absent or
partial baselines fail closed. The pinned workflow also attests both bundles'
complete validator/schema/dependency tuples against workflow-owned fingerprints.
When these managed tools change, include the matching new reviewed workflow pin
and its explicit previous-base compatibility entry in the same upgrade PR.
Project facts, stricter policy and native instructions are validated separately.
For an old three-role consumer upgrading to the extended Copilot package, that
matching workflow pin must also contain the workflow-owned new-asset guard; the
old base validator alone cannot validate the added profiles, skills and path rules.
Scoped `.gitattributes` preserves LF only for the eight attested tooling files.
SHA values render in lowercase and existing caller pins remain preserved during
ordinary Copier updates.

The optional `use_quality_framework` choice is also installation-only; missing
legacy answers mean false. Adoption changes need a separately reviewed migration,
without editing answers to bypass that restriction.



